package com.jinjin.books.bean.utils;

public enum Del_flag {
    /**
     * 是否删除的枚举类型
     */

    YES("yes",0),NO("no",1);
    public String name;
    public int code;
    private Del_flag(String name,int code){
        this.code  = code;
        this.name = name;
    }

}
