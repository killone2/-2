package com.jinjin.books.bean.Servlet;

import com.jinjin.books.bean.bean.Department;
import com.jinjin.books.bean.service.Impl.DepartmentServiceImpl;
import com.jinjin.books.bean.utils.Constant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
@WebServlet(name = "DepartmentServlet",urlPatterns = "/departmentServlet")
public class DepartmentServlet extends HttpServlet {
    DepartmentServiceImpl departmentService = new DepartmentServiceImpl();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String type = req.getParameter(Constant.REQUEST_PATAMETER_TYPE);
        if(type!=null&&Constant.SERVLET_TYPE_SAVE.equals(type))
        {
            try {
                SaveOrUpdate(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else if(type!=null&&Constant.SERVLET_TYPE_DELETED.equals(type)){
            Integer id = Integer.parseInt(req.getParameter("id"));
            try {
                departmentService.delete(id);
                QueryList(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else if(type!=null&&Constant.SERVLET_TYPE_QUERYBYID.equals(type)){
            int id = Integer.parseInt(req.getParameter("id"));
            try {
                Department department = departmentService.QueryById(id);
                req.setAttribute("department",department);
                req.getRequestDispatcher("/department/departmentUpdate.jsp").forward(req,resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            QueryList(req, resp);
        }

    }

    private void SaveOrUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
        Department department = new Department();
        int id = 0;
        if(req.getParameter("id")!=null)
        {
            id = Integer.parseInt(req.getParameter("id"));
        }
        department.setId(id);
        department.setDepartment(req.getParameter("department"));
        department.setDept_desc(req.getParameter("dept_desc"));
        if(id>0)
        {
            departmentService.update(department);
            QueryList(req, resp);
        }
        else{
            try {
                departmentService.save(department);
                QueryList(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }

    private void QueryList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            List<Department> list = departmentService.list();
            req.setAttribute("list",list);
            req.getRequestDispatcher("/department/department.jsp").forward(req, resp);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws
            ServletException, IOException {
        this.doPost(req,resp);
    }
}
