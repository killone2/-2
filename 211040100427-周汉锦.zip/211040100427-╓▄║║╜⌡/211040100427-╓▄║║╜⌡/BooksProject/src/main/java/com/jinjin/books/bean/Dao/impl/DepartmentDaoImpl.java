package com.jinjin.books.bean.Dao.impl;

import com.jinjin.books.bean.Dao.IDepartment;
import com.jinjin.books.bean.bean.Department;
import com.jinjin.books.bean.utils.Del_flag;
import com.jinjin.books.bean.utils.MyDBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDaoImpl implements IDepartment {
    QueryRunner queryRunner = MyDBUtils.getQueryRunner();
    String sql;
    @Override
    public List<Department> list() throws SQLException {
        sql = "select * from t_department where is_deleted = ?";
        List<Department> list;
        list = queryRunner.query(sql, new ResultSetHandler<List<Department>>() {
            @Override
            public List<Department> handle(ResultSet resultSet) throws SQLException {
                List<Department> list = new ArrayList<>();
                while(resultSet.next())
                {
                    Department department = new Department();
                    department.setId(resultSet.getInt("id"));
                    department.setDepartment(resultSet.getString("department"));
                    department.setDept_desc(resultSet.getString("dept_desc"));
                    list.add(department);
                }
                return list;
            }
        }, Del_flag.NO.code);
        return list;
    }

    @Override
    public Integer save(Department department) throws SQLException {
        sql = "insert into t_department (department,dept_desc,is_deleted) values(?,?,?)";
        return queryRunner.update(sql,department.getDepartment(),department.getDept_desc(),Del_flag.NO.code);
    }

    @Override
    public Integer update(Department department) throws SQLException {
        sql = "update t_department set department = ?,dept_desc=? where id = ?";
        return queryRunner.update(sql,department.getDepartment(),department.getDept_desc(),department.getId());
    }

    @Override
    public Integer delete(Integer id) throws SQLException {
        sql = "update t_department set is_deleted=? where id = ?";
        return queryRunner.update(sql,Del_flag.YES.code,id);
    }

    @Override
    public Department QueryById(Integer id) throws SQLException {
        sql = "select * from t_department where is_deleted = ? and  id = ?";
        Department department;
        department = queryRunner.query(sql, new ResultSetHandler<Department>() {
            @Override
            public Department handle(ResultSet resultSet) throws SQLException {
                Department department = new Department();
                while(resultSet.next())
                {
                    department.setId(resultSet.getInt("id"));
                    department.setDepartment(resultSet.getString("department"));
                    department.setDept_desc(resultSet.getString("dept_desc"));
                }
                return department;
            }
        }, Del_flag.NO.code,id);
        return department;
    }
}
