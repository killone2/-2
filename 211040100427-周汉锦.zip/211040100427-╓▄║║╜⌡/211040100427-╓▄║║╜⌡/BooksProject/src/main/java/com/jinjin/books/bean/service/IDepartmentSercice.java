package com.jinjin.books.bean.service;

import com.jinjin.books.bean.bean.Department;
import com.jinjin.books.bean.bean.User;

import java.sql.SQLException;
import java.util.List;

public interface IDepartmentSercice {
    public List<Deprecated> list() throws SQLException;
    public Integer add(Department department) throws SQLException;
    public Integer delete(Integer id) throws SQLException;
    public Department queryById(Integer id) throws SQLException;
    public Integer Update(Department department) throws SQLException;
}
