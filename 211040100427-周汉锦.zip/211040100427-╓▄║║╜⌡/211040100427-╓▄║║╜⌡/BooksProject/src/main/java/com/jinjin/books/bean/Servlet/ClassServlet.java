package com.jinjin.books.bean.Servlet;

import com.jinjin.books.bean.bean.Classes;
import com.jinjin.books.bean.bean.Department;
import com.jinjin.books.bean.service.Impl.ClassServiceImpl;
import com.jinjin.books.bean.service.Impl.DepartmentServiceImpl;
import com.jinjin.books.bean.utils.Constant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "ClassServlet",urlPatterns = "/classServlet")
public class ClassServlet extends HttpServlet {
    ClassServiceImpl classService = new ClassServiceImpl();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String type = req.getParameter(Constant.REQUEST_PATAMETER_TYPE);
        if(Constant.QueryAllDept.equals(type))
        {
            QueryAllDept(req,resp);
            req.getRequestDispatcher("/class/classUpdate.jsp").forward(req,resp);
        }else if(Constant.SERVLET_TYPE_SAVE.equals(type)) {
            try {
                SaveOrUpdate(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else if(Constant.SERVLET_TYPE_QUERYBYID.equals(type))
        {
            QueryAllDept(req, resp);
            int id = Integer.parseInt(req.getParameter("id"));
            System.out.println(id);
            try {
                Classes classes = classService.queryById(id);
                req.setAttribute("classes",classes);
                req.getRequestDispatcher("/class/classUpdate.jsp").forward(req,resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else if(Constant.SERVLET_TYPE_DELETED.equals(type))
        {
            int id = Integer.parseInt(req.getParameter("id"));
            try {
                classService.delete(id);
                QueryList(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else{
            QueryList(req, resp);
        }
    }

    private void SaveOrUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
        Classes classes = new Classes();
        int id = 0;
        if(req.getParameter("id")!=null)
        {
            id = Integer.parseInt(req.getParameter("id"));
            classes.setId(id);
        }
        try {
            Department department = new DepartmentServiceImpl().QueryById(Integer.valueOf(req.getParameter("Dept_id")));
            classes.setDept_id(department.getId());
            classes.setDept_name(department.getDepartment());
            classes.setClass_name(req.getParameter("class_name"));
            System.out.println(department);
            classes.setDept_name(department.getDepartment());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if(id>0)
        {
            classService.Update(classes);
            QueryList(req, resp);
        }else{
            try {
                classService.add(classes);
                QueryList(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void QueryAllDept(HttpServletRequest req, HttpServletResponse resp) {
        try {
            List<Department> dept = new DepartmentServiceImpl().list();
            req.setAttribute("depts",dept);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void QueryList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        try {
            List<Classes> list = classService.list();
            req.setAttribute("list",list);
            req.getRequestDispatcher("/class/class.jsp").forward(req, resp);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
