package com.jinjin.books.bean.Dao.impl;

import com.jinjin.books.bean.Dao.IUserDao;
import com.jinjin.books.bean.bean.User;
import com.jinjin.books.bean.utils.Del_flag;
import com.jinjin.books.bean.utils.MyDBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 用户Dao接口实现类
 * 命名规范：放在Impl子包中，以Impl结尾
 */
public  class UserDaoimpl implements IUserDao {

    @Override
    public List<User> list(User user) throws SQLException {
        //通过DBUtils
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        //构建Sql
        String sql = "select * from t_user where is_deleted = ?";
        List<User> List;
        List = queryRunner.query(sql, resultSet -> {
            List<User> List1 = new ArrayList<>();
            while (resultSet.next()) {
                User user1 = new User();
                user1.setId(resultSet.getInt("id"));
                user1.setUser_name(resultSet.getString("user_name"));
                user1.setPassword(resultSet.getString("password"));
                user1.setPhone_num(resultSet.getString("phone_num"));
                user1.setEmail(resultSet.getString("email"));
                user1.setIs_deleted(resultSet.getInt("is_deleted"));
                user1.setSalt(resultSet.getString("salt"));
                List1.add(user1);
            }
            return List1;
        },Del_flag.NO.code);

        return List;
    }

    /**
     * 添加用户
     * @param user
     * @return
     */
    @Override
    public Integer save(User user) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "Insert into t_user (user_name,password,phone_num,email,is_deleted)values(?,?,?,?,?)";
        return queryRunner.update(sql,user.getUser_name(),
                user.getPassword(),
                user.getPhone_num(),
                user.getEmail(),
                Del_flag.NO.code);
    }

    @Override
    public Integer deleteById(Integer id) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "update t_user set is_deleted = ? where id = ?";
        return queryRunner.update(sql, Del_flag.YES.code,id);
    }

    @Override
    public User queryById(Integer id) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "select * from t_user where id = ? and is_deleted = ?";
        return queryRunner.query(sql, new ResultSetHandler<User>() {
            @Override
            public User handle(ResultSet resultSet) throws SQLException {
                if(resultSet.next())
                {
                    User user = new User();
                    user.setId(resultSet.getInt("id"));
                    user.setUser_name(resultSet.getString("user_name"));
                    user.setPassword(resultSet.getString("password"));
                    user.setPhone_num(resultSet.getString("phone_num"));
                    user.setEmail(resultSet.getString("email"));
                    return user;
                }
                return null;
            }
        },id,Del_flag.NO.code);
    }

    @Override
    public Integer UpdateById(User user) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "Update t_user set user_name = ?,password = ?,phone_num=?,email=? where id = ? ";
        return queryRunner.update(sql,user.getUser_name(),user.getPassword(),user.getPhone_num(),user.getEmail(),user.getId());
    }

    @Override
    public String checkUserName(String userName) {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "select count(1) from t_user where is_deleted = ? and user_name = ?";
        try {
            int count = queryRunner.query(sql, new ResultSetHandler<Integer>() {
                @Override
                public Integer handle(ResultSet rs) throws SQLException {
                    rs.next();
                    int count = rs.getInt(1);
                    return count;
                }
            },Del_flag.NO.code,userName);
            return count == 0 ? "success" : "error";
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return "error";
    }

    @Override
    public User checkUserNameAndPassword(String userName, String password) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "select * from t_user where is_deleted=? and user_name =? and password=?";
        return queryRunner.query(sql, new ResultSetHandler<User>() {
            @Override
            public User handle(ResultSet resultSet) throws SQLException {
                if(resultSet.next())
                {
                    User user = new User();
                    user.setId(resultSet.getInt("id"));
                    user.setUser_name(resultSet.getString("user_name"));
                    user.setPassword(resultSet.getString("password"));
                    user.setPhone_num(resultSet.getString("phone_num"));
                    user.setEmail(resultSet.getString("email"));
                    return user;
                }
                return null;
            }
        },Del_flag.NO.code,userName,password);
    }

    public static void main(String[] args) throws SQLException {
        UserDaoimpl dap = new UserDaoimpl();
        for(User user:dap.list(null))
        {
            System.out.println(user);
        }
    }
}
