package com.jinjin.books.bean.utils;

public class Constant {
    public static final String REQUEST_PATAMETER_TYPE="type";
    public static final String SERVLET_TYPE_SAVE = "save";
    public static final String SERVLET_TYPE_UPDATE = "update";
    public static final String SERVLET_TYPE_DELETED="delete";
    public  static final String SERVLET_TYPE_QUERY = "query";
    public static final String SERVLET_TYPE_QUERYBYID= "queryById";
    public static final String SERVLET_TYPE_CHECK="check";
    public static final String SEVLET_LOGIN_USER = "loginUser";
    public static final String QueryAllDept = "QueryAllDept";
}

