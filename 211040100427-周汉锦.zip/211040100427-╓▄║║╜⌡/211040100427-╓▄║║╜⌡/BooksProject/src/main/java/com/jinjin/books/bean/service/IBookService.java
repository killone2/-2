package com.jinjin.books.bean.service;

import com.jinjin.books.bean.bean.Book;

import java.sql.SQLException;
import java.util.List;

public interface IBookService {
    public  List<Book> list(Book book) throws SQLException;
    public Integer save(Book book) throws SQLException;
    public Integer delete(Book book) throws SQLException;
    public Integer Update(Book book) throws SQLException;
    public Book QueryById(Integer id) throws SQLException;
}
