package com.jinjin.books.bean.Dao.impl;

import com.jinjin.books.bean.Dao.IStudentDao;
import com.jinjin.books.bean.bean.Student;
import com.jinjin.books.bean.utils.Del_flag;
import com.jinjin.books.bean.utils.MyDBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDaoImpl implements IStudentDao {
    QueryRunner queryRunner = MyDBUtils.getQueryRunner();
    String sql;
    @Override
    public List<Student> list() throws SQLException {
        sql = "select * from t_student where is_deleted = ?";
        List<Student> list;
        list = queryRunner.query(sql, resultSet -> {
            List<Student> list1 = new ArrayList<>();
            while(resultSet.next())
            {
                Student student = new Student();
                student.setId(resultSet.getInt("id"));
                student.setStu_name(resultSet.getString("stu_name"));
                student.setStu_num(resultSet.getString("stu_num"));
                student.setPhone_num(resultSet.getString("phone_num"));
                student.setGender(resultSet.getString("gender"));
                student.setAddress(resultSet.getString("address"));
                student.setClassid(resultSet.getInt("classid"));
                student.setClass_name(resultSet.getString("class_name"));
                student.setDeptart_id(resultSet.getInt("depart_id"));
                student.setDepart_name(resultSet.getString("depart_name"));
                list1.add(student);
            }
            return list1;
        }, Del_flag.NO.code);
        return list;
    }

    @Override
    public Integer save(Student student) throws SQLException {
        sql = "Insert into t_student (id,stu_name,stu_num,phone_num,gender,address,classid,class_name,depart_id,depart_name,is_deleted) values(?,?,?,?,?,?,?,?,?,?,?)";
        return queryRunner.update(sql,student.getId(),student.getStu_name(),student.getStu_num(),student.getPhone_num(),student.getGender(),student.getAddress(),student.getClassid(),student.getClass_name(),student.getDeptart_id(),student.getDepart_name(),Del_flag.NO.code);
    }

    @Override
    public Integer update(Student student) throws SQLException {
        sql = "update t_student set stu_name=?,stu_num=?,phone_num=?,gender=?,address=?,classid=?,class_name=?,depart_id=?,depart_name=? where id=?";
        return queryRunner.update(sql,student.getStu_name(),student.getStu_num(),student.getPhone_num(),student.getGender(),student.getAddress(),student.getClassid(),student.getClass_name(),student.getDeptart_id(),student.getDepart_name(),student.getId());
    }

    @Override
    public Integer delete(Integer id) throws SQLException {
        sql = "update t_student set is_deleted = ? where id=?";
        return queryRunner.update(sql,Del_flag.YES.code,id);
    }

    @Override
    public Student QueryById(Integer id) throws SQLException {
        sql = "select * from t_student where id = ?";
        Student student;
        student = queryRunner.query(sql, new ResultSetHandler<Student>() {
            @Override
            public Student handle(ResultSet resultSet) throws SQLException {
                Student student1 = new Student();
                while(resultSet.next())
                {
                    student1.setId(resultSet.getInt("id"));
                    student1.setStu_name(resultSet.getString("stu_name"));
                    student1.setStu_num(resultSet.getString("stu_num"));
                    student1.setPhone_num(resultSet.getString("phone_num"));
                    student1.setGender(resultSet.getString("gender"));
                    student1.setAddress(resultSet.getString("address"));
                    student1.setClassid(resultSet.getInt("classid"));
                    student1.setClass_name(resultSet.getString("class_name"));
                    student1.setDeptart_id(resultSet.getInt("depart_id"));
                    student1.setDepart_name(resultSet.getString("depart_name"));
                }
                return student1;
            }
    },id);
        return student;
    }
}
