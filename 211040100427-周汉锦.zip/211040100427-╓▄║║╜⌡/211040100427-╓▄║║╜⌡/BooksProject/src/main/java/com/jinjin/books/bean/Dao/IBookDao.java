package com.jinjin.books.bean.Dao;

import com.jinjin.books.bean.bean.Book;

import java.sql.SQLException;
import java.util.List;
import java.util.function.IntToDoubleFunction;

public interface IBookDao {
    /**
     * 查询书籍信息
     */
    public List<Book> list(Book book) throws SQLException;
    /**
     * 添加书籍信息
     */
    public Integer saveBook(Book book) throws SQLException;
    /**
     *更新书籍信息
     */
    public Integer updateBook(Book book) throws SQLException;
    /**
     * 根据编号删除书籍
     */
    public Integer deleteBook(Book book) throws SQLException;
    /**
     * 根据id查找书籍
     */
    public Book QueryById(Integer id) throws SQLException;
}
