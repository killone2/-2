package com.jinjin.books.bean.Servlet;

import com.jinjin.books.bean.bean.User;
import com.jinjin.books.bean.service.IUserService;
import com.jinjin.books.bean.service.Impl.UserServiceImpl;
import com.jinjin.books.bean.utils.Constant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
@WebServlet(name="loginServlet",urlPatterns = "/loginServlet")
public class logInServlet extends HttpServlet {

    IUserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //实现登录功能
        //获取表单提交的账号密码
        //调用Service的方法
        //根据验证的结果做出对应的响应
        req.setCharacterEncoding("UTF-8");
        String userName = req.getParameter("user_name");
        String password = req.getParameter("password");
        try {
            User user = userService.checkUserNameAndpassword(userName,password);
            HttpSession session = req.getSession();
            if(user!=null)
            {
                session.setAttribute(Constant.SEVLET_LOGIN_USER,user);
                resp.sendRedirect("/main.jsp");
            }
            else{
                session.setAttribute("msg","账号密码错误");
                resp.sendRedirect("login.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
