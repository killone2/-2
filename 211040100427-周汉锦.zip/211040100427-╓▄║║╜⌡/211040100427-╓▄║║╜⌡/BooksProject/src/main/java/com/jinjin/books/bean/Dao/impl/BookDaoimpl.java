package com.jinjin.books.bean.Dao.impl;

import com.jinjin.books.bean.Dao.IBookDao;
import com.jinjin.books.bean.bean.Book;
import com.jinjin.books.bean.utils.Constant;
import com.jinjin.books.bean.utils.Del_flag;
import com.jinjin.books.bean.utils.MyDBUtils;
import com.sun.javaws.IconUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDaoimpl implements IBookDao {

    @Override
    public List<Book> list(Book book) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "select * from t_book where is_deleted = ?";
        List<Book> list ;
        list = queryRunner.query(sql, resultSet -> {
            List<Book> list1 = new ArrayList<>();
            while(resultSet.next())
            {
                Book book1 = new Book();
                book1.setBook_name(resultSet.getString("book_name"));
                book1.setId(resultSet.getInt("id"));
                book1.setAuthor(resultSet.getString("author"));
                book1.setPublish(resultSet.getString("publish"));
                book1.setIsbn(resultSet.getString("isbn"));
                book1.setIntroduction(resultSet.getString("introduction"));
                book1.setLanguage(resultSet.getString("language"));
                book1.setPrice(resultSet.getBigDecimal("price"));
                book1.setPubdate(resultSet.getDate("pubdate"));
                book1.setPressmark(resultSet.getString("pressmark"));
                book1.setState(resultSet.getInt("state"));
                book1.setIs_deleted(resultSet.getInt("is_deleted"));
                assert list1 != null;
                list1.add(book1);
            }
            return list1;
        }, Del_flag.NO.code);
        return list;
    }

    @Override
    public Integer saveBook(Book book) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "Insert into t_book (book_name,author,publish,isbn,introduction,language,price,pubdate,pressmark,state,is_deleted) values(?,?,?,?,?,?,?,?,?,?,?)";
        return queryRunner.update(sql,book.getBook_name(),
                book.getAuthor(),
                book.getPublish(),
                book.getIsbn(),
                book.getIntroduction(),
                book.getLanguage(),
                book.getPrice(),
                book.getPubdate(),
                book.getPressmark(),
                book.getState(),
                book.getIs_deleted());
    }

    @Override
    public Integer updateBook(Book book) throws SQLException {
        /**
         *  修改功能
         */
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "update t_book set book_name=?,author=?,publish=?,isbn=?,introduction=?,language=?,price=?,pubdate=?,pressmark=?,state=? where id=?";
        return queryRunner.update(sql,book.getBook_name(),
                book.getAuthor(),
                book.getPublish(),
                book.getIsbn(),
                book.getIntroduction(),
                book.getLanguage(),
                book.getPrice(),
                book.getPubdate(),
                book.getPressmark(),
                book.getState(),
                book.getId());
    }

    @Override
    public Integer deleteBook(Book book) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "update t_book set is_deleted = ? where id = ?";
        System.out.println(book.getId());
        return queryRunner.update(sql,Del_flag.YES.code,book.getId());
    }

    @Override
    public Book QueryById(Integer id) throws SQLException {
        QueryRunner queryRunner = MyDBUtils.getQueryRunner();
        String sql = "select * from t_book where id = ?";
        Book book = queryRunner.query(sql, resultSet -> {
            Book book1 = new Book();
            while(resultSet.next())
            {
                book1.setBook_name(resultSet.getString("book_name"));
                book1.setId(resultSet.getInt("id"));
                book1.setAuthor(resultSet.getString("author"));
                book1.setPublish(resultSet.getString("publish"));
                book1.setIsbn(resultSet.getString("isbn"));
                book1.setIntroduction(resultSet.getString("introduction"));
                book1.setLanguage(resultSet.getString("language"));
                book1.setPrice(resultSet.getBigDecimal("price"));
                book1.setPubdate(resultSet.getDate("pubdate"));
                book1.setPressmark(resultSet.getString("pressmark"));
                book1.setState(resultSet.getInt("state"));
                book1.setIs_deleted(resultSet.getInt("is_deleted"));
            }
            return book1;
        },id);
        return book;
    }
}
