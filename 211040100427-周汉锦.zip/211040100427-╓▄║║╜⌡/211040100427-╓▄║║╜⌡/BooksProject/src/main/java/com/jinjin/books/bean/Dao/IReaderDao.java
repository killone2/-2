package com.jinjin.books.bean.Dao;

import com.jinjin.books.bean.bean.Subscrib;

import java.sql.SQLException;
import java.util.List;

public interface IReaderDao {
    /**
     * 查询借书卡信息
     */
    public List<Subscrib> list() throws SQLException;
    /**
     * 添加借书卡信息
     */
    public Integer save(Subscrib readerCard) throws SQLException;
    /**
     *更新借书卡信息
     */
    public Integer update(Subscrib readerCard) throws SQLException;
    /**
     * 根据卡号删除借书卡信息
     */
    public Integer delete(Integer id) throws SQLException;
}
