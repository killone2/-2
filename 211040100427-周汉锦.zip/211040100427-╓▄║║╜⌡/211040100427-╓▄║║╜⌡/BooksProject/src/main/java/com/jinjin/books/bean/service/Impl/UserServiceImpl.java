package com.jinjin.books.bean.service.Impl;

import com.jinjin.books.bean.Dao.IUserDao;
import com.jinjin.books.bean.Dao.impl.UserDaoimpl;
import com.jinjin.books.bean.bean.User;
import com.jinjin.books.bean.service.IUserService;

import java.sql.SQLException;
import java.util.List;

/**
 * 用户Service接口实现
 * 通过和Dao的调用来完成复杂的业务处理
 */
public class UserServiceImpl implements IUserService {
    private IUserDao userDao = new UserDaoimpl();
    @Override
    public List<User> getUser(User user) throws SQLException {
        return userDao.list(null);
    }

    @Override
    public Integer addUser(User user) throws SQLException {
        return userDao.save(user);
    }

    @Override
    public Integer deleteById(Integer id) throws SQLException {
        return userDao.deleteById(id);
    }

    @Override
    public User queryById(Integer id) throws SQLException {
        return userDao.queryById(id);
    }

    @Override
    public Integer UpdateById(User user) throws SQLException {
        return userDao.UpdateById(user);
    }

    @Override
    public String checkUserName(String userName) throws SQLException {
        return userDao.checkUserName(userName);
    }

    @Override
    public User checkUserNameAndpassword(String userName, String password) throws SQLException {
        return userDao.checkUserNameAndPassword(userName,password);
    }
}
