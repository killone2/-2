package com.jinjin.books.bean.service.Impl;

import com.jinjin.books.bean.Dao.IStudentDao;
import com.jinjin.books.bean.Dao.impl.StudentDaoImpl;
import com.jinjin.books.bean.bean.Student;
import com.jinjin.books.bean.service.IStudentService;

import java.sql.SQLException;
import java.util.List;

public class StudentServiceImpl implements IStudentService {
    StudentDaoImpl studentDao  = new StudentDaoImpl();
    @Override
    public List<Student> list() throws SQLException {
        return studentDao.list();
    }

    @Override
    public Integer add(Student student) throws SQLException {
        return studentDao.save(student);
    }

    @Override
    public Integer delete(Integer id) throws SQLException {
        return studentDao.delete(id);
    }

    @Override
    public Student queryById(Integer id) throws SQLException {
        return studentDao.QueryById(id);
    }

    @Override
    public Integer Update(Student student) throws SQLException {
        return studentDao.update(student);
    }
}
