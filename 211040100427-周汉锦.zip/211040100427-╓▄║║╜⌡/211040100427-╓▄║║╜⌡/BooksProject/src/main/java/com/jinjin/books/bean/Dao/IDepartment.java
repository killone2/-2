package com.jinjin.books.bean.Dao;

import com.jinjin.books.bean.bean.Book;
import com.jinjin.books.bean.bean.Department;

import java.sql.SQLException;
import java.util.List;

public interface IDepartment {
    /**
     * 查询学院信息
     */
    public List<Department> list() throws SQLException;
    /**
     * 添加学院信息
     */
    public Integer save(Department department) throws SQLException;
    /**
     *更新学院信息
     */
    public Integer update(Department department) throws SQLException;
    /**
     * 根据编号删除院系信息
     */
    public Integer delete(Integer id) throws SQLException;
    /**
     * 根据id查找书籍
     */
    public Department QueryById(Integer id) throws SQLException;
}
