package com.jinjin.books.bean.service;

import com.jinjin.books.bean.bean.Classes;
import com.jinjin.books.bean.bean.Department;

import java.sql.SQLException;
import java.util.List;

public interface IClassService {
    public List<Classes> list() throws SQLException;
    public Integer add(Classes classes) throws SQLException;
    public Integer delete(Integer id) throws SQLException;
    public Classes queryById(Integer id) throws SQLException;
    public Integer Update(Classes classes) throws SQLException;
    public List<Classes> QueryByDEID(Integer id) throws SQLException;
}
