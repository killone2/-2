package com.jinjin.books.bean.service.Impl;

import com.jinjin.books.bean.Dao.IDepartment;
import com.jinjin.books.bean.Dao.impl.DepartmentDaoImpl;
import com.jinjin.books.bean.bean.Department;

import java.sql.SQLException;
import java.util.List;

public class DepartmentServiceImpl implements IDepartment {
    DepartmentDaoImpl departmentDao = new DepartmentDaoImpl();
    @Override
    public List<Department> list() throws SQLException {
        return departmentDao.list();
    }

    @Override
    public Integer save(Department department) throws SQLException {
        return departmentDao.save(department);
    }

    @Override
    public Integer update(Department department) throws SQLException {
        return departmentDao.update(department);
    }

    @Override
    public Integer delete(Integer id) throws SQLException {
        return departmentDao.delete(id);
    }

    @Override
    public Department QueryById(Integer id) throws SQLException {
        return departmentDao.QueryById(id);
    }
}
