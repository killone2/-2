package com.jinjin.books.bean.bean;

import java.math.BigDecimal;
import java.util.Date;

public class Book {
    private Integer id;
    private String book_name;
    private String author;
    private String publish;
    private String isbn;
    private String introduction;
    private String language;
    private BigDecimal price;
    private Date pubdate;
    private String pressmark;
    private Integer state;
    private Integer is_deleted;

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", book_name='" + book_name + '\'' +
                ", author='" + author + '\'' +
                ", publish='" + publish + '\'' +
                ", isbn='" + isbn + '\'' +
                ", introduction='" + introduction + '\'' +
                ", language='" + language + '\'' +
                ", price=" + price +
                ", pubdate=" + pubdate +
                ", pressmark='" + pressmark + '\'' +
                ", state=" + state +
                ", is_deleted=" + is_deleted +
                '}';
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublish(String publish) {
        this.publish = publish;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setPubdate(Date pubdate) {
        this.pubdate = pubdate;
    }

    public void setPressmark(String pressmark) {
        this.pressmark = pressmark;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public void setIs_deleted(Integer is_deleted) {
        this.is_deleted = is_deleted;
    }

    public Integer getId() {
        return id;
    }

    public String getBook_name() {
        return book_name;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublish() {
        return publish;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getIntroduction() {
        return introduction;
    }

    public String getLanguage() {
        return language;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public Date getPubdate() {
        return pubdate;
    }

    public String getPressmark() {
        return pressmark;
    }

    public Integer getState() {
        return state;
    }

    public Integer getIs_deleted() {
        return is_deleted;
    }
}
