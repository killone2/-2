package com.jinjin.books.bean.Filter;

import com.jinjin.books.bean.utils.Constant;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 所有的请求判断登陆状态
 * 是则放过，不是则跳转登录界面
 */
@WebFilter(filterName = "authenticationFilter",urlPatterns ="/*")
public class filter  implements Filter {
    public void init(FilterConfig config) throws ServletException {

    }

    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest servletRequest = (HttpServletRequest)request;
        HttpServletResponse servletResponse = (HttpServletResponse)response;
        //获取请求地址
        String requestURI = servletRequest.getRequestURI();
        if(requestURI.contains("login.jsp") || requestURI.contains("loginServlet")){
            chain.doFilter(request,response);
        }else{
            HttpSession session = servletRequest.getSession();
            Object Attribute =  session.getAttribute(Constant.SEVLET_LOGIN_USER);
            if(Attribute!=null){
                //说明登陆过了，放行
                chain.doFilter(request,response);
            }
            else{
                session.setAttribute("msg","请先登录！");
                servletResponse.sendRedirect("/login.jsp");
            }
        }
    }
}
