package com.jinjin.books.bean.service;

import com.jinjin.books.bean.bean.Classes;
import com.jinjin.books.bean.bean.Student;

import java.sql.SQLException;
import java.util.List;

public interface IStudentService {
    public List<Student> list() throws SQLException;
    public Integer add(Student student) throws SQLException;
    public Integer delete(Integer id) throws SQLException;
    public Student queryById(Integer id) throws SQLException;
    public Integer Update(Student student) throws SQLException;
}
