package com.jinjin.books.bean.Dao;

import com.jinjin.books.bean.bean.Department;
import com.jinjin.books.bean.bean.Student;

import java.sql.SQLException;
import java.util.List;

public interface IStudentDao {
    /**
     * 查询学生信息
     */
    public List<Student> list() throws SQLException;
    /**
     * 添加学生信息
     */
    public Integer save(Student student) throws SQLException;
    /**
     *更新学生信息
     */
    public Integer update(Student student) throws SQLException;
    /**
     * 根据编号删除学生信息
     */
    public Integer delete(Integer id) throws SQLException;
    /**
     * 根据id查找学生
     */
    public Student QueryById(Integer id) throws SQLException;
}
