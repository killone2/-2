package com.jinjin.books.bean.service.Impl;

import com.jinjin.books.bean.Dao.ISubscribDao;
import com.jinjin.books.bean.Dao.impl.ISubscribImpl;
import com.jinjin.books.bean.bean.Book;
import com.jinjin.books.bean.bean.Subscrib;
import com.jinjin.books.bean.service.ISubscribService;

import java.sql.SQLException;
import java.util.List;

public class SubscribServiceImpl implements ISubscribService {
    ISubscribImpl iSubscrib = new ISubscribImpl();
    @Override
    public List<Subscrib> list() throws SQLException {
        return iSubscrib.list();
    }

    @Override
    public Integer save(Book book) throws SQLException {
        return null;
    }

    @Override
    public Integer delete(Book book) throws SQLException {
        return null;
    }

    @Override
    public Integer Update(Book book) throws SQLException {
        return null;
    }

    @Override
    public Book QueryById(Integer id) throws SQLException {
        return null;
    }
}
