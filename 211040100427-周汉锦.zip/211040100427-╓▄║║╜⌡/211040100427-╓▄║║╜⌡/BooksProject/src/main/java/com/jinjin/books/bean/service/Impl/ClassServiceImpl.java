package com.jinjin.books.bean.service.Impl;

import com.jinjin.books.bean.Dao.impl.ClassesDapImpl;
import com.jinjin.books.bean.bean.Classes;
import com.jinjin.books.bean.service.IClassService;

import java.sql.SQLException;
import java.util.List;

public class ClassServiceImpl implements IClassService {
    ClassesDapImpl classesDap = new ClassesDapImpl();
    @Override
    public List<Classes> list() throws SQLException {
        return classesDap.list();
    }

    @Override
    public Integer add(Classes classes) throws SQLException {
        return classesDap.save(classes);
    }

    @Override
    public Integer delete(Integer id) throws SQLException {
        return classesDap.delete(id);
    }

    @Override
    public Classes queryById(Integer id) throws SQLException {
        return classesDap.QueryById(id);
    }

    @Override
    public Integer Update(Classes classes) throws SQLException {
        return classesDap.Update(classes);
    }

    @Override
    public List<Classes> QueryByDEID(Integer id) throws SQLException {
        return classesDap.QueryByDEID(id);
    }

}
