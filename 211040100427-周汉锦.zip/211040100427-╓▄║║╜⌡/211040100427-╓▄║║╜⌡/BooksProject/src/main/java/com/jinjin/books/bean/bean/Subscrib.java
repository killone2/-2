package com.jinjin.books.bean.bean;

import java.util.Date;

public class Subscrib {
    private Integer id;
    private String book;
    private String stuName;
    private String department;
    public Date LDate;
    private Date BDate;
    private String classname;
    private Integer is_deleted;

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }



    public String getBook() {
        return book;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public Date getLDate() {
        return LDate;
    }

    public void setLDate(Date LDate) {
        this.LDate = LDate;
    }

    public Date getBDate() {
        return BDate;
    }

    public void setBDate(Date BDate) {
        this.BDate = BDate;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        classname = classname;
    }

    public Integer getIs_deleted() {
        return is_deleted;
    }

    public void setIs_deleted(Integer is_deleted) {
        this.is_deleted = is_deleted;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }



}
