package com.jinjin.books.bean.Servlet;

import com.jinjin.books.bean.bean.User;
import com.jinjin.books.bean.service.IUserService;
import com.jinjin.books.bean.service.Impl.UserServiceImpl;
import com.jinjin.books.bean.utils.Constant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * 接收请求
 * 响应请求--》通过Service处理请求
 */
@WebServlet(name = "UserServlet",urlPatterns = "/userServlet")
public class UserSetvlet extends HttpServlet {

    private IUserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    /**
     * 统一处理浏览器提交的http://localhost8080/userServlet的请求
     * @param req 封装请求相关信息
     * @param resp 响应
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置post请求中数据的解码方式
        req.setCharacterEncoding("UTF-8");
        String type = req.getParameter(Constant.REQUEST_PATAMETER_TYPE);
        if(type!=null&&!"".equals(type)){
            if(Constant.SERVLET_TYPE_SAVE.equals(type)){
                SaveOrUpdate(req, resp);
            }
            else if(Constant.SERVLET_TYPE_DELETED.equals(type)){
                //删除用户信息
                String id = req.getParameter("id");
                //通过Service删除操作
                try {
                    userService.deleteById(Integer.parseInt(id));
                    queryUser(req, resp);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            else if(Constant.SERVLET_TYPE_QUERY.equals(type)){
                //查询用户信息
            }
            else if(Constant.SERVLET_TYPE_UPDATE.equals(type)){

            }
            else if(Constant.SERVLET_TYPE_QUERYBYID.equals(type))
            {
                String id = req.getParameter("id");
                try {
                    User user = userService.queryById(Integer.parseInt(id));
                    req.setAttribute("user",user);
                    req.getRequestDispatcher("/user/userUpdate.jsp").forward(req,resp);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            else if(Constant.SERVLET_TYPE_CHECK.equals(type)){
                //验证账号是否存在
                String userName = req.getParameter("userName");
                try {
                    String s = userService.checkUserName(userName);
                    resp.getWriter().println(s);
                    resp.flushBuffer();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }
        }
        else{
            queryUser(req, resp);
        }

    }

    private void SaveOrUpdate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User user = new User();
        user.setUser_name(req.getParameter("user_name"));
        user.setPassword(req.getParameter("password"));
        user.setPhone_num(req.getParameter("phone_num"));
        user.setEmail(req.getParameter("email"));
        int id = 0;
        if(req.getParameter("id")!=null)
        {
            id = Integer.parseInt(req.getParameter("id"));
        }
        user.setId(id);
        if(user.getId()!=null&&user.getId()>0)
        {
            try {
                userService.UpdateById(user);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            resp.sendRedirect("/userServlet");
        }
        else{
            try {
                userService.addUser(user);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            resp.sendRedirect("/userServlet");
        }
    }


    /**
     * 代码抽取操作
     * 查询用户信息
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */

    private void queryUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //查询用户
        try {
            List<User>list = userService.getUser(null);
            req.setAttribute("list",list);
            req.getRequestDispatcher("/user/user.jsp").forward(req, resp);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}