package com.jinjin.books.bean.Servlet;

import com.jinjin.books.bean.bean.Book;
import com.jinjin.books.bean.bean.User;
import com.jinjin.books.bean.service.Impl.BookServiceImpl;
import com.jinjin.books.bean.utils.Constant;
import com.jinjin.books.bean.utils.Del_flag;
import com.mysql.cj.x.protobuf.MysqlxCrud;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet(name = "BookServlet",urlPatterns = "/bookServlet")
public class BookServlet extends HttpServlet {
    BookServiceImpl BookService = new BookServiceImpl();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String type = req.getParameter(Constant.REQUEST_PATAMETER_TYPE);
        if(type!=null&&type.equals(Constant.SERVLET_TYPE_SAVE))
        {
            try {
                SaveOrUpdate(req, resp);
            } catch (ParseException | SQLException e) {
                e.printStackTrace();
            }
        }else if(type!=null&&Constant.SERVLET_TYPE_DELETED.equals(type))
        {
            Book book = new Book();
            int id = Integer.parseInt(req.getParameter("id"));
            book.setId(id);;
            try {
                BookService.delete(book);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            QueryBook(req, resp);
        }else if(Constant.SERVLET_TYPE_QUERYBYID.equals(type))
        {
            String id = req.getParameter("id");
            try {
                Book book = BookService.QueryById(Integer.parseInt(id));
                req.setAttribute("book",book);
                req.getRequestDispatcher("/book/bookUpdate.jsp").forward(req,resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            QueryBook(req, resp);
        }
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    private void SaveOrUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ParseException, SQLException {
        Book book = new Book();
        int id = 0;
        if(req.getParameter("id")!=null)
        {
            id = Integer.parseInt(req.getParameter("id"));
        }
        book.setBook_name(req.getParameter("book_name"));
        book.setAuthor(req.getParameter("author"));
        book.setPublish(req.getParameter("publish"));
        book.setIsbn(req.getParameter("isbn"));
        book.setPrice(new BigDecimal(req.getParameter("price")));
        String strDate = req.getParameter("pubdate");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        book.setPubdate(sdf.parse(strDate));
        book.setPressmark(req.getParameter("pressmark"));
        book.setIntroduction(req.getParameter("introduction"));
        book.setLanguage(req.getParameter("language"));
        book.setState(Integer.parseInt(req.getParameter("state")));
        book.setIs_deleted(Del_flag.NO.code);
        book.setId(id);
        if(id>0&&book.getId()!=null)
        {
            BookService.Update(book);
            QueryBook(req, resp);
        }
        else{
            try {
                if(book.getBook_name()!=null)
                {
                    int count = BookService.save(book);
                    QueryBook(req, resp);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void QueryBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            List<Book> list = BookService.list(null);
            req.setAttribute("list",list);
            req.getRequestDispatcher("/book/book.jsp").forward(req, resp);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
