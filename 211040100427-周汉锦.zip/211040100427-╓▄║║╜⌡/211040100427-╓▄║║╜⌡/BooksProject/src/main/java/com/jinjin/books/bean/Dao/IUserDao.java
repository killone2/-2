package com.jinjin.books.bean.Dao;

import com.jinjin.books.bean.bean.User;

import java.sql.SQLException;
import java.util.List;

/**
 * 用户的持久层接口
 * 作者：呆猫
 */
public interface IUserDao {
    /**
     * 根据用户信息查询用户
     * @param user
     * @return
     */
    public List<User> list(User user) throws SQLException;
    public Integer save(User user) throws SQLException;
    public Integer deleteById(Integer id) throws SQLException;//根据id删除用户信息
    public User queryById(Integer id) throws SQLException;
    public Integer UpdateById(User user) throws SQLException;
    public String checkUserName(String userName) throws SQLException;//检查账号是否存在
    public User checkUserNameAndPassword(String userName,String password) throws SQLException;
    /**
     * 登录
     *
     */
}

