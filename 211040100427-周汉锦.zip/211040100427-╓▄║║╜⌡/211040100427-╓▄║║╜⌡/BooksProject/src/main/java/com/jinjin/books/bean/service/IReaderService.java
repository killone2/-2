package com.jinjin.books.bean.service;

import com.jinjin.books.bean.bean.Subscrib;

import java.sql.SQLException;
import java.util.List;

public interface IReaderService {
    public List<Subscrib> list() throws SQLException;
    public Integer add(Subscrib readerCard) throws SQLException;
    public Integer delete(Integer id) throws SQLException;
    public Integer Update(Subscrib readerCard) throws SQLException;
}
