package com.jinjin.books.bean.Dao.impl;

import com.jinjin.books.bean.Dao.ClassesDao;
import com.jinjin.books.bean.bean.Classes;
import com.jinjin.books.bean.utils.Del_flag;
import com.jinjin.books.bean.utils.MyDBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClassesDapImpl implements ClassesDao {
    QueryRunner queryRunner = MyDBUtils.getQueryRunner();
    String sql;
    @Override
    public List<Classes> list() throws SQLException {
        sql = "select * from t_class where is_deleted = ?";
        List<Classes> list;
        list = queryRunner.query(sql, new ResultSetHandler<List<Classes>>() {
            @Override
            public List<Classes> handle(ResultSet resultSet) throws SQLException {
                List<Classes> list = new ArrayList<>();
                while(resultSet.next())
                {
                    Classes classes = new Classes();
                    classes.setId(resultSet.getInt("id"));
                    classes.setDept_id(resultSet.getInt("dept_id"));
                    classes.setClass_name(resultSet.getString("class_name"));
                    classes.setDept_name(resultSet.getString("dept_name"));
                    list.add(classes);
                }
                return list;
            }
        }, Del_flag.NO.code);
        return list;
    }

    @Override
    public Integer save(Classes classes) throws SQLException {
        sql = "insert into t_class (id,class_name,dept_id,dept_name,is_deleted) values(?,?,?,?,?)";
        return queryRunner.update(sql,classes.getId(),classes.getClass_name(),classes.getDept_id(),classes.getDept_name(),Del_flag.NO.code);
    }

    @Override
    public Integer delete(Integer id) throws SQLException {
        sql = "update t_class set is_deleted = ? where id =?";
        return queryRunner.update(sql,Del_flag.YES.code,id);
    }

    @Override
    public Integer Update(Classes classes) throws SQLException {
        sql = "update t_class set class_name =?,dept_id=?,dept_name=? where id = ?";
        return queryRunner.update(sql,classes.getClass_name(),classes.getDept_id(),classes.getDept_name(),classes.getId());
    }

    @Override
    public Classes QueryById(Integer id) throws SQLException {
        sql = "select * from t_class where id = ?";
        Classes classes;
        classes = queryRunner.query(sql, new ResultSetHandler<Classes>() {
            @Override
            public Classes handle(ResultSet resultSet) throws SQLException {
                Classes classes = new Classes();
                while(resultSet.next())
                {
                    classes.setId(resultSet.getInt("id"));
                    classes.setDept_id(resultSet.getInt("dept_id"));
                    classes.setClass_name(resultSet.getString("class_name"));
                    classes.setDept_name(resultSet.getString("dept_name"));
                }
                return classes;
            }
        }, id);
        return classes;
    }

    @Override
    public List<Classes> QueryByDEID(Integer id) throws SQLException {
        sql = "select * from t_class where dept_id = ? and is_deleted = ?";
        List<Classes> list;
        list = queryRunner.query(sql, new ResultSetHandler<List<Classes>>() {
            @Override
            public List<Classes> handle(ResultSet resultSet) throws SQLException {
                List<Classes> list = new ArrayList<>();
                while(resultSet.next())
                {
                    Classes classes = new Classes();
                    classes.setDept_id(id);
                    classes.setId(resultSet.getInt("id"));
                    classes.setClass_name(resultSet.getString("class_name"));
                    list.add(classes);
                }
                return list;
            }
        },id,Del_flag.NO.code);
        return list;
    }
}
