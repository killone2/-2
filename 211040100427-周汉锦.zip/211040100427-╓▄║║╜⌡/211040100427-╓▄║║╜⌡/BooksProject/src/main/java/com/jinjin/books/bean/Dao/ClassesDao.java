package com.jinjin.books.bean.Dao;

import com.jinjin.books.bean.bean.Classes;

import java.sql.SQLException;
import java.util.List;

public interface ClassesDao {
    //查询操作，返回班级列表
    public List<Classes> list() throws SQLException;
    //增加班级
    public Integer save(Classes classes) throws SQLException;
    //删除班级
    public Integer delete(Integer id) throws SQLException;
    //修改班级
    public Integer Update(Classes classes) throws SQLException;
    //查找单个班级
    public Classes QueryById(Integer id) throws SQLException;
    //查找一类班级
    public List<Classes> QueryByDEID(Integer id) throws SQLException;
}
