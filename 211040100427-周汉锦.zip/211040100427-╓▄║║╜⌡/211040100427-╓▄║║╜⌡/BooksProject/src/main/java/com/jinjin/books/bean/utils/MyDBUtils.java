package com.jinjin.books.bean.utils;

import com.mysql.cj.jdbc.MysqlDataSource;
import org.apache.commons.dbutils.QueryRunner;

/**
 * 数据库的 工具类
 */

public class MyDBUtils {
    private static MysqlDataSource dataSource;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        dataSource = new MysqlDataSource();
        dataSource.setUrl("jdbc:mysql://localhost:3306/book?serverTimezone=UTC&useUnicode=true&characterEncoding=utf8");
        dataSource.setUser("root");
        dataSource.setPassword("1234");
    }
    public static QueryRunner getQueryRunner(){
        return new QueryRunner(dataSource);
    }
}
/**
 * 给外界提供一个获取QueryRunner对象的方法
 * @return
 */
