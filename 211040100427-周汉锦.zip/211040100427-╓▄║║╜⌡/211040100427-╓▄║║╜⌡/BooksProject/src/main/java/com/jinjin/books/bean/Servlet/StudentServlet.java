package com.jinjin.books.bean.Servlet;

import com.alibaba.fastjson.JSON;
import com.jinjin.books.bean.bean.Classes;
import com.jinjin.books.bean.bean.Department;
import com.jinjin.books.bean.bean.Student;
import com.jinjin.books.bean.service.Impl.ClassServiceImpl;
import com.jinjin.books.bean.service.Impl.DepartmentServiceImpl;
import com.jinjin.books.bean.service.Impl.StudentServiceImpl;
import com.jinjin.books.bean.utils.Constant;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name="StudentServlet",urlPatterns = "/studentservlet")
public class StudentServlet extends HttpServlet {
    StudentServiceImpl studentService = new StudentServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String type = req.getParameter(Constant.REQUEST_PATAMETER_TYPE);
        if(Constant.QueryAllDept.equals(type))
        {
            QueryAllDept(req, resp);
            req.getRequestDispatcher("/student/studentUpdate.jsp").forward(req,resp);

        }else if(Constant.SERVLET_TYPE_SAVE.equals(type))
        {
            SaveOrUpdate(req);
            QueryList(req, resp);
        }else if("QueryClassByDept_id".equals(type))
        {
            int id = Integer.parseInt(req.getParameter("Dept_id"));
            ClassServiceImpl classService = new ClassServiceImpl();
            try {
                List<Classes> list = classService.QueryByDEID(id);
                String json = JSON.toJSONString(list);
                resp.setContentType("application/json;charset=UTF-8");
                PrintWriter writer = resp.getWriter();
                writer.println(json);
                writer.flush();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else if(Constant.SERVLET_TYPE_DELETED.equals(type))
        {
            int id = Integer.parseInt(req.getParameter("id"));
            try {
                studentService.delete(id);
                QueryList(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else if(Constant.SERVLET_TYPE_QUERYBYID.equals(type)){
            int id = Integer.parseInt(req.getParameter("id"));
            try {
                Student student = studentService.queryById(id);
                req.setAttribute("student",student);
                QueryAllDept(req, resp);
                req.getRequestDispatcher("/student/studentUpdate.jsp").forward(req,resp);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else{
            QueryList(req, resp);
        }

    }

    private void SaveOrUpdate(HttpServletRequest req) {
        Student student = new Student();
        int id = 0;
        if(req.getParameter("id")!=null)
        {
            id = Integer.parseInt(req.getParameter("id"));
            student.setId(id);
        }
        student.setStu_num(req.getParameter("stu_num"));
        student.setStu_name(req.getParameter("stu_name"));
        student.setPhone_num(req.getParameter("phone_num"));
        student.setGender(req.getParameter("gender"));
        student.setAddress(req.getParameter("address"));
        int dept_id = 0;
        dept_id = Integer.parseInt(req.getParameter("Dept_id"));
        try {
            Department department = new DepartmentServiceImpl().QueryById(dept_id);
            if(department!=null){
                student.setDeptart_id(dept_id);
                student.setDepart_name(department.getDepartment());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if(req.getParameter("Class_id")!=null)
        {
            int Id = Integer.parseInt(req.getParameter("Class_id"));
            try {
                Classes classes = new ClassServiceImpl().queryById(Id);
                student.setClass_name(classes.getClass_name());
                System.out.println(student.getClass_name());
                student.setClassid(Id);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(id>0)
        {
            try {
                studentService.Update(student);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else{
            try {
                studentService.add(student);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void QueryList (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            List<Student> list = studentService.list();
            req.setAttribute("list",list);
            req.getRequestDispatcher("/student/student.jsp").forward(req, resp);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void QueryAllDept(HttpServletRequest req, HttpServletResponse resp) {
        try {
            List<Department> dept = new DepartmentServiceImpl().list();
            req.setAttribute("depts",dept);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
