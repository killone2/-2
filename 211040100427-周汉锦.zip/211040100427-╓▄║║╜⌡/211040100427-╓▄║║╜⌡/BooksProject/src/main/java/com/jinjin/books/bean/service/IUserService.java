package com.jinjin.books.bean.service;

import com.jinjin.books.bean.bean.User;

import java.sql.SQLException;
import java.util.List;

public interface IUserService {
    public List<User> getUser(User user) throws SQLException;
    public Integer addUser(User user) throws SQLException;
    public Integer deleteById(Integer id) throws SQLException;
    public User queryById(Integer id) throws SQLException;
    public Integer UpdateById(User user) throws SQLException;
    public String checkUserName(String userName) throws SQLException;
    public User checkUserNameAndpassword(String userName,String password) throws SQLException;
}
