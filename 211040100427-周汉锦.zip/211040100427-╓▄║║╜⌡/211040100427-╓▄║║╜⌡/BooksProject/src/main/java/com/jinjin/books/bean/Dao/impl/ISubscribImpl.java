package com.jinjin.books.bean.Dao.impl;

import com.jinjin.books.bean.Dao.ISubscribDao;
import com.jinjin.books.bean.bean.Student;
import com.jinjin.books.bean.bean.Subscrib;
import com.jinjin.books.bean.utils.Del_flag;
import com.jinjin.books.bean.utils.MyDBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ISubscribImpl implements ISubscribDao {
    QueryRunner queryRunner = MyDBUtils.getQueryRunner();
    String sql;
    @Override
    public List<Subscrib> list() throws SQLException {
        sql = "select * from subscrib where is_deleted = ?";
        List<Subscrib> list;
        list = queryRunner.query(sql, new ResultSetHandler<List<Subscrib>>() {
            @Override
            public List<Subscrib> handle(ResultSet resultSet) throws SQLException {
                List<Subscrib> list1 = new ArrayList<>();

                while(resultSet.next())
                {
                    Subscrib subscrib = new Subscrib();
                    subscrib.setId(resultSet.getInt("Id"));
                    subscrib.setStuName(resultSet.getString("name"));
                    subscrib.setClassname(resultSet.getString("Class"));
                    subscrib.setLDate(resultSet.getDate("L_Date"));
                    subscrib.setBDate(resultSet.getDate("B_Date"));
                    subscrib.setBook(resultSet.getString("book"));
                    subscrib.setDepartment(resultSet.getString("department"));
                    list1.add(subscrib);
                }
                return list1;
            }
        }, Del_flag.NO.code);
        return list;
    }

    @Override
    public Integer save(Student student) throws SQLException {
        return null;
    }

    @Override
    public Integer update(Student student) throws SQLException {
        return null;
    }

    @Override
    public Integer delete(Integer id) throws SQLException {
        return null;
    }

    @Override
    public Student QueryById(Integer id) throws SQLException {
        return null;
    }
}
