package com.jinjin.books.bean.service.Impl;

import com.jinjin.books.bean.Dao.IBookDao;
import com.jinjin.books.bean.Dao.impl.BookDaoimpl;
import com.jinjin.books.bean.bean.Book;
import com.jinjin.books.bean.service.IBookService;

import java.sql.SQLException;
import java.util.List;

public class BookServiceImpl implements IBookService {
    BookDaoimpl BookDao = new BookDaoimpl();

    @Override
    public List<Book> list(Book book) throws SQLException {
        return BookDao.list(null);
    }

    @Override
    public Integer save(Book book) throws SQLException {
        return BookDao.saveBook(book);
    }

    @Override
    public Integer delete(Book book) throws SQLException {
        return BookDao.deleteBook(book);
    }

    @Override
    public Integer Update(Book book) throws SQLException {
        return BookDao.updateBook(book);
    }

    @Override
    public Book QueryById(Integer id) throws SQLException {
        return BookDao.QueryById(id);
    }

}
